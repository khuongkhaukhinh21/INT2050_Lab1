package henry.app.android.puzzlegame;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class SelectLevel extends Activity {
    Button level1;
    Button level2;
    Button level3;
    Button level4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.select_level);

        level1 = findViewById(R.id.level1);
        level2 = findViewById(R.id.level2);
        level3 = findViewById(R.id.level3);
        level4 = findViewById(R.id.level4);
    }

    public void startLevel1(View view) {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(50);

        Intent startGame = new Intent(SelectLevel.this, puzzleCat.class);
        startActivity(startGame);
    }

    public void startLevel2(View view) {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(50);

        Intent startGame = new Intent(SelectLevel.this, puzzleReyna.class);
        startActivity(startGame);
    }

    public void startLevel3(View view) {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(50);

        Intent startGame = new Intent(SelectLevel.this, puzzleEzreal.class);
        startActivity(startGame);
    }

    public void startLevel4(View view) {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(50);

        Intent startGame = new Intent(SelectLevel.this, puzzleDog.class);
        startActivity(startGame);
    }

}
