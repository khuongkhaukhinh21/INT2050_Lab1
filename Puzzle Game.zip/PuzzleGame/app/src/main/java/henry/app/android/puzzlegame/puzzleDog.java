package henry.app.android.puzzlegame;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class puzzleDog extends AppCompatActivity {
    private Chronometer stopWatch;
    //private RelativeLayout myLayout = null;
    private ImageView[] puzzleImage = new ImageView[36];
    private ImageView tempImageRandom = null;
    private TextView text = null;
    private RelativeLayout myLayout = null;
    private MediaPlayer touch = null;
    private float x;
    private float y;

    //Set up
    private final int startX = 120;
    private final int startY = 50;
    private final int length = 140;
    private final int row = 6;
    private final int column = 6;
    private final int total = row * column;
    private int puzzle_x[] = new int[row];
    private int puzzle_y[] = new int[column];


    //All variables
    private int move = 0;
    private int piece = 6;
    private int boxNull = 35;
    private int[][] box = {
            {0,1,2,3,4,5},
            {6,7,8,9,10,11},
            {12,13,14,15,16,17},
            {18,19,20,21,22,23},
            {24,25,26,27,28,29},
            {30,31,32,33,34,35},
    };
    private int boxTarget = 0;
    private int[] right = new int[total];
    private int[] yours = new int[total];

    //Puzzle Random
    private int[] indexPuzzleImageRandom = new int[total];
    private ImageView[] puzzleImageRandom = new ImageView[total];


    //Methods to get Puzzle Random
    public int randomNumber(){
        Random rn = new Random();
        int randomNum = rn.nextInt(4);
        return randomNum;
    }

    public int findIndex(int box){
        for (int i = 0 ; i < indexPuzzleImageRandom.length ; i++){
            if (indexPuzzleImageRandom[i] == box){
                return i;
            }
        }
        return -1;
    }

    public void turnDown(int[] indexPuzzleImageRandom){
        if (findIndex(boxNull) - column >= 0){
            int indexNull = findIndex(boxNull);
            indexPuzzleImageRandom[findIndex(boxNull)] = indexPuzzleImageRandom[indexNull - column];
            indexPuzzleImageRandom[indexNull - column] = boxNull;
        }
    }

    public void turnUp(int[] indexPuzzleImageRandom){
        if (findIndex(boxNull) + column <= total - 1){
            int indexNull = findIndex(boxNull);
            indexPuzzleImageRandom[findIndex(boxNull)] = indexPuzzleImageRandom[indexNull + column];
            indexPuzzleImageRandom[indexNull + column] = boxNull;
        }
    }

    public void turnLeft(int[] indexPuzzleImageRandom){
        if ((findIndex(boxNull) + 1) % column != 0){
            int indexNull = findIndex(boxNull);
            indexPuzzleImageRandom[findIndex(boxNull)] = indexPuzzleImageRandom[indexNull + 1];
            indexPuzzleImageRandom[indexNull + 1] = boxNull;
        }
    }

    public void turnRight(int[] indexPuzzleImageRandom) {
        if (findIndex(boxNull) % column != 0) {
            int indexNull = findIndex(boxNull);
            indexPuzzleImageRandom[findIndex(boxNull)] = indexPuzzleImageRandom[indexNull - 1];
            indexPuzzleImageRandom[indexNull - 1] = boxNull;
        }
    }

    public void randomImage(int times, int[] indexPuzzleImageRandom){
        int turn = 0;
        for (int i = 1 ; i <= times ; i++){
            turn = randomNumber();
            if (turn == 1){
                turnDown(indexPuzzleImageRandom);
            }
            else if (turn == 2){
                turnUp(indexPuzzleImageRandom);
            }
            else if (turn == 3){
                turnLeft(indexPuzzleImageRandom);
            }
            else{
                turnRight(indexPuzzleImageRandom);
            }
        }

        while (findIndex(boxNull) + column <= total - 1){
            turnUp(indexPuzzleImageRandom);
        }
        while ((findIndex(boxNull) + 1) % column != 0){
            turnLeft(indexPuzzleImageRandom);
        }
    }

    //Methods to set up puzzleImage
    public void setUp(){
        puzzleImage[0] = (ImageView) findViewById(R.id.dog1);
        puzzleImage[1] = (ImageView) findViewById(R.id.dog2);
        puzzleImage[2] = (ImageView) findViewById(R.id.dog3);
        puzzleImage[3] = (ImageView) findViewById(R.id.dog4);
        puzzleImage[4] = (ImageView) findViewById(R.id.dog5);
        puzzleImage[5] = (ImageView) findViewById(R.id.dog6);
        puzzleImage[6] = (ImageView) findViewById(R.id.dog7);
        puzzleImage[7] = (ImageView) findViewById(R.id.dog8);
        puzzleImage[8] = (ImageView) findViewById(R.id.dog9);
        puzzleImage[9] = (ImageView) findViewById(R.id.dog10);
        puzzleImage[10] = (ImageView) findViewById(R.id.dog11);
        puzzleImage[11] = (ImageView) findViewById(R.id.dog12);
        puzzleImage[12] = (ImageView) findViewById(R.id.dog13);
        puzzleImage[13] = (ImageView) findViewById(R.id.dog14);
        puzzleImage[14] = (ImageView) findViewById(R.id.dog15);
        puzzleImage[15] = (ImageView) findViewById(R.id.dog16);
        puzzleImage[16] = (ImageView) findViewById(R.id.dog17);
        puzzleImage[17] = (ImageView) findViewById(R.id.dog18);
        puzzleImage[18] = (ImageView) findViewById(R.id.dog19);
        puzzleImage[19] = (ImageView) findViewById(R.id.dog20);
        puzzleImage[20] = (ImageView) findViewById(R.id.dog21);
        puzzleImage[21] = (ImageView) findViewById(R.id.dog22);
        puzzleImage[22] = (ImageView) findViewById(R.id.dog23);
        puzzleImage[23] = (ImageView) findViewById(R.id.dog24);
        puzzleImage[24] = (ImageView) findViewById(R.id.dog25);
        puzzleImage[25] = (ImageView) findViewById(R.id.dog26);
        puzzleImage[26] = (ImageView) findViewById(R.id.dog27);
        puzzleImage[27] = (ImageView) findViewById(R.id.dog28);
        puzzleImage[28] = (ImageView) findViewById(R.id.dog29);
        puzzleImage[29] = (ImageView) findViewById(R.id.dog30);
        puzzleImage[30] = (ImageView) findViewById(R.id.dog31);
        puzzleImage[31] = (ImageView) findViewById(R.id.dog32);
        puzzleImage[32] = (ImageView) findViewById(R.id.dog33);
        puzzleImage[33] = (ImageView) findViewById(R.id.dog34);
        puzzleImage[34] = (ImageView) findViewById(R.id.dog35);
        puzzleImage[35] = (ImageView) findViewById(R.id.dog36);
    }

    //Primary Function
    //Draw Random Puzzle on screen
    public void drawPuzzle(ImageView[] puzzleImageRandom){
        int count = 0;
        for (int i = 0 ; i < row ; i++){
            for (int j = 0 ; j < column ; j++) {
                puzzleImageRandom[count].setX(startX + j*length);
                puzzleImageRandom[count].setY(startY + i*length);
                count++;
            }
        }
    }
    //Check condition of winning game
    public boolean compareTwoArray(int[] right, int[] yours){
        for (int i = 0 ; i < right.length ; i++){
            if (right[i] != yours[i]) return false;
        }
        return true;
    }

    public void showWinning() {
        AlertDialog.Builder gameOver = new AlertDialog.Builder(puzzleDog.this);
        gameOver.setCancelable(false);
        gameOver.setTitle("Game Over!");
        gameOver.setMessage("Congratulations!!!" + "\n" + "You have solved this puzzle in " + stopWatch.getText());
        stopWatch.stop();
        gameOver.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //RESTART
                Intent welcomeScreen = new Intent(puzzleDog.this, WelcomeScreen.class);
                finish();
                //RESTART ACTIVITY
                startActivity(welcomeScreen);
            }
        });
        gameOver.show();
    }

    //Main loop
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.puzzle_dog);
        stopWatch = findViewById(R.id.stopwatch);
        stopWatch.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer){
                if (((String) stopWatch.getText()).equals("00:59:59")) {
                    stopWatch.setFormat("0%s");
                }

                if (((String) stopWatch.getText()).equals("09:59:59")) {
                    stopWatch.setFormat("%s");
                }
            }
        });
        stopWatch.start();
        setUp();
        //Set up
        for (int i = 0 ; i < row ; i++){
            puzzle_x[i] = startX + i*length;
        }

        for (int j = 0 ; j < column; j++){
            puzzle_y[j] = startY + j*length;
        }


        //ALl variables
        for (int i = 0 ; i < total ; i++){
            right[i] = i;
        }

        //Puzzle Random
        for (int i = 0 ; i < total ; i++){
            indexPuzzleImageRandom[i] = i;
        }

        randomImage(10000, indexPuzzleImageRandom);

        for (int i = 0 ; i < total ; i++){
            puzzleImageRandom[i] = puzzleImage[indexPuzzleImageRandom[i]];
            yours[i] = indexPuzzleImageRandom[i];
        }

        //Primary Function Start Here
        drawPuzzle(puzzleImageRandom);

        //Text view
        text = (TextView) findViewById(R.id.text);

        touch = MediaPlayer.create(puzzleDog.this, R.raw.click);
        myLayout = (RelativeLayout) findViewById(R.id.myLayout);
        myLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                x = motionEvent.getX();
                y = motionEvent.getY();
                //text.setText(yours[4] + " " + right[4]) ;
                if (compareTwoArray(right, yours)){
                    showWinning();
                }
                if ( (x >= startX && x <= startX + length * piece) && (y >= startY && y <= startY + length * piece)) {
                    boxTarget = box[(int) ((y - startY) / length)][(int) ((x - startX) / length)];
                    //move down
                    if (boxTarget - boxNull == column && boxNull + column <= total - 1) {
                        //Play sound
                        touch.start();
                        //Change image location
                        float nullY = puzzleImageRandom[boxNull].getY();
                        float targetY = puzzleImageRandom[boxTarget].getY();
                        puzzleImageRandom[boxTarget].setY(nullY);
                        puzzleImageRandom[boxNull].setY(targetY);
                        //Change image in array
                        tempImageRandom = puzzleImageRandom[boxTarget];
                        puzzleImageRandom[boxTarget] = puzzleImageRandom[boxNull];
                        puzzleImageRandom[boxNull] = tempImageRandom;
                        //Change index in array
                        int tempIndex = yours[boxNull];
                        yours[boxNull] = yours[boxTarget];
                        yours[boxTarget] = tempIndex;
                        //Change boxNull;
                        boxNull += column;

                    }
                    //move up
                    else if (boxNull - boxTarget == column && boxNull - column >= 0) {
                        //Play sound
                        touch.start();
                        //Change image location
                        float nullY = puzzleImageRandom[boxNull].getY();
                        float targetY = puzzleImageRandom[boxTarget].getY();
                        puzzleImageRandom[boxTarget].setY(nullY);
                        puzzleImageRandom[boxNull].setY(targetY);
                        //Change image in array
                        tempImageRandom = puzzleImageRandom[boxTarget];
                        puzzleImageRandom[boxTarget] = puzzleImageRandom[boxNull];
                        puzzleImageRandom[boxNull] = tempImageRandom;
                        //Change index in array
                        int tempIndex = yours[boxNull];
                        yours[boxNull] = yours[boxTarget];
                        yours[boxTarget] = tempIndex;
                        //Change boxNull;
                        boxNull -= column;

                    }
                    //move right
                    else if (boxTarget - boxNull == 1 && (boxNull + 1) % column != 0) {
                        //Play sound
                        touch.start();
                        //Change image location
                        float nullX = puzzleImageRandom[boxNull].getX();
                        float targetX = puzzleImageRandom[boxTarget].getX();
                        puzzleImageRandom[boxTarget].setX(nullX);
                        puzzleImageRandom[boxNull].setX(targetX);
                        //Change image in array
                        tempImageRandom = puzzleImageRandom[boxTarget];
                        puzzleImageRandom[boxTarget] = puzzleImageRandom[boxNull];
                        puzzleImageRandom[boxNull] = tempImageRandom;
                        //Change index in array
                        int tempIndex = yours[boxNull];
                        yours[boxNull] = yours[boxTarget];
                        yours[boxTarget] = tempIndex;
                        //Change boxNull;
                        boxNull += 1;
                    }
                    //move left
                    else if (boxNull - boxTarget == 1 && boxNull % column != 0) {
                        //Play sound
                        touch.start();
                        //Change image location
                        float nullX = puzzleImageRandom[boxNull].getX();
                        float targetX = puzzleImageRandom[boxTarget].getX();
                        puzzleImageRandom[boxTarget].setX(nullX);
                        puzzleImageRandom[boxNull].setX(targetX);
                        //Change image in array
                        tempImageRandom = puzzleImageRandom[boxTarget];
                        puzzleImageRandom[boxTarget] = puzzleImageRandom[boxNull];
                        puzzleImageRandom[boxNull] = tempImageRandom;
                        //Change index in array
                        int tempIndex = yours[boxNull];
                        yours[boxNull] = yours[boxTarget];
                        yours[boxTarget] = tempIndex;
                        //Change boxNull;
                        boxNull -= 1;
                    }
                }
                return true;
            }
        });


    }
}