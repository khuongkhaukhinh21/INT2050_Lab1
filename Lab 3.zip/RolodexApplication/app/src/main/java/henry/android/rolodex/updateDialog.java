package henry.android.rolodex;

import android.app.Activity;

public class updateDialog extends Activity {
}
