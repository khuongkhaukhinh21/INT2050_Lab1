package henry.android.rolodex;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {

    public static final String RECORD_TABLE = "RECORD_TABLE";
    public static final String FIRST_NAME = "FIRST_NAME";
    public static final String LAST_NAME = "LAST_NAME";
    public static final String ID = "ID";
    public static final String MIDDLE_NAME = "M" + ID + "DLE_NAME";
    public static final String PHONE = "PHONE";
    public static final String DATABASE_NAME = "rolex.db";

    public DataBaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + RECORD_TABLE + " (" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + FIRST_NAME + " TEXT, " + LAST_NAME + " TEXT, " + MIDDLE_NAME + " TEXT, " + PHONE + " TEXT)";
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public boolean addOne(String firstName, String lastName, String middleName, String phone){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(FIRST_NAME, firstName);
        cv.put(LAST_NAME, lastName);
        cv.put(MIDDLE_NAME, middleName);
        cv.put(PHONE, phone);
        long insert = db.insert(RECORD_TABLE, null, cv);
        if (insert == -1){
            return false;
        }
        else {
            return true;
        }
    }

    public boolean updateData(String id, String firstName, String lastName, String middleName, String phone){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(ID, id);
        cv.put(FIRST_NAME, firstName);
        cv.put(LAST_NAME, lastName);
        cv.put(MIDDLE_NAME, middleName);
        cv.put(PHONE, phone);
        db.update(RECORD_TABLE, cv, "ID = ?", new String[]{id});
        return true;

    }

    public boolean DeleteOne(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + RECORD_TABLE + " WHERE " + ID + " = " + id;

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()){
            return true;
        }
        else {
            return false;
        }
    }

    //index 1 to get FirstName, 2 to get LastName, 3 to get MiddleName, 4 to get PhoneNumber
    public List<String> getList(int index){
        List<String> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM " + RECORD_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()){
            do{
                String value = cursor.getString(index);
                returnList.add(value);

            } while(cursor.moveToNext());
        }
        else{
            // failure
        }

        cursor.close();
        db.close();
        return returnList;
    }

    public void updateId(){
        String queryString = "SELECT * FROM " + RECORD_TABLE;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);
    }

    public void deleteDatabase(Context context){
        context.deleteDatabase(DATABASE_NAME);
    }




}
