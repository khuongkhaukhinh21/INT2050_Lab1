package henry.android.rolodex;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements addRolodex.ExampleDialogListener{

    //test

    String fullName, fullPhone;
    ListView rolodexList;
    String[] from = {"select","name", "phone"};
    int[] to = {R.id.tvSelect, R.id.tvName, R.id.tvPhone};
    List<HashMap<String, Object>> list = new ArrayList<>();
    private int index = 0;
    HashMap<String, Object> item[] = new HashMap[300];

    ArrayList<String> listFirstName = new ArrayList<>(300);
    ArrayList<String> listLastName = new ArrayList<>(300);
    ArrayList<String> listMiddleName = new ArrayList<>(300);
    ArrayList<String> listPhoneNumber = new ArrayList<>(300);


    private Button openAddDialog, updateButton, deleteButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rolodexList = findViewById(R.id.rolodexList);

        //Put saved records
        put_saved_records();

        //Add
        openAddDialog = findViewById(R.id.addButton);
        openAddDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addDialog();
            }
        });

        //Update
        updateButton = findViewById(R.id.updateButton);
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (countSelectItem() == 0)
                    Toast.makeText(MainActivity.this, "Select 1 record to update!", Toast.LENGTH_SHORT).show();
                else if (countSelectItem() > 1)
                    Toast.makeText(MainActivity.this, "Cannot select more than 1 record!", Toast.LENGTH_SHORT).show();
                else {
                    updateDialog();
                }
            }
        });

        //Delete
        deleteButton = findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (countSelectItem() != 0) openConfirmDialog();
                else Toast.makeText(MainActivity.this, "Select at least 1 record to delete!", Toast.LENGTH_SHORT).show();
            }
        });


        rolodexList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                selectItem(i);
            }
        });



    }

    private void put_saved_records() {
        DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);
        List<String> listFirstNameDefault = dataBaseHelper.getList(1);
        List<String> listLastNameDefault = dataBaseHelper.getList(2);
        List<String> listMiddleNameDefault = dataBaseHelper.getList(3);
        List<String> listPhoneNumberDefault = dataBaseHelper.getList(4);

        for (int i = 0; i < listFirstNameDefault.size(); i++){
            listFirstName.add(listFirstNameDefault.get(i));
            listLastName.add(listLastNameDefault.get(i));
            listMiddleName.add(listMiddleNameDefault.get(i));
            listPhoneNumber.add(listPhoneNumberDefault.get(i));
            item[index] = new HashMap<>();
            item[index].put("select", "");
            fullName = "\t\t\t" + listLastNameDefault.get(i) + ", " + listFirstNameDefault.get(i) + " " + listMiddleNameDefault.get(i);
            item[index].put("name", fullName);
            fullPhone = "\t\t\t\t\t" + listPhoneNumberDefault.get(i);
            item[index].put("phone", fullPhone);
            list.add(item[index]);
            index++;
        }
        SimpleAdapter adapter = new SimpleAdapter(this, list, R.layout.item_layout, from, to);
        rolodexList.setAdapter(adapter);
    }

    public void addDialog(){
        addRolodex dialog = new addRolodex();
        dialog.show(getSupportFragmentManager(), "addRolodex");
    }

    @Override
    public void applyTexts(String getFirstName, String getLastName, String getMiddleName, String getPhoneNumber) {
        if (getFirstName.equals("")){
            Toast.makeText(MainActivity.this, "The entered record is INVALID!!!", Toast.LENGTH_LONG).show();
        }
        else {
            listFirstName.add(getFirstName);
            listLastName.add(getLastName);
            listMiddleName.add(getMiddleName);
            listPhoneNumber.add(getPhoneNumber);
            item[index] = new HashMap<>();
            item[index].put("select", "");
            fullName = "\t\t\t" +  getLastName + ", " + getFirstName + " " + getMiddleName;
            item[index].put("name", fullName);
            fullPhone = "\t\t\t\t\t" + getPhoneNumber;
            item[index].put("phone", fullPhone);

            DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);
            boolean success = dataBaseHelper.addOne(getFirstName, getLastName, getMiddleName, getPhoneNumber);

            Toast.makeText(MainActivity.this, "Successfully add the record", Toast.LENGTH_SHORT).show();

            list.add(item[index]);
            SimpleAdapter adapter = new SimpleAdapter(this, list, R.layout.item_layout, from, to);
            rolodexList.setAdapter(adapter);
            index++;
        }
    }

    public void updateDialog(){
        Dialog updateDialog = new Dialog(MainActivity.this);
        updateDialog.setContentView(R.layout.update_dialog);
        updateDialog.setTitle("Update Record");
        updateDialog.show();

        EditText firstName = updateDialog.findViewById(R.id.firstName);
        EditText lastName = updateDialog.findViewById(R.id.lastName);
        EditText middleName = updateDialog.findViewById(R.id.middleName);
        EditText phoneNumber = updateDialog.findViewById(R.id.phoneNumber);
        Button cancel = updateDialog.findViewById(R.id.cancel);
        Button update = updateDialog.findViewById(R.id.update);

        int selectedIndex = getSelectItem();
        firstName.setText(listFirstName.get(selectedIndex));
        lastName.setText(listLastName.get(selectedIndex));
        middleName.setText(listMiddleName.get(selectedIndex));
        phoneNumber.setText(listPhoneNumber.get(selectedIndex));

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateDialog.dismiss();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validation(firstName.getText().toString(), lastName.getText().toString(), middleName.getText().toString(), phoneNumber.getText().toString())) {
                    //item[selectedIndex] = new HashMap<>();
                    item[selectedIndex].put("select", "");
                    item[selectedIndex].put("name", "\t\t\t" + lastName.getText() + ", " + firstName.getText() + " " + middleName.getText());
                    item[selectedIndex].put("phone", "\t\t\t\t\t" + phoneNumber.getText());
                    list.set(selectedIndex, item[selectedIndex]);
                    SimpleAdapter adapter = new SimpleAdapter(MainActivity.this, list, R.layout.item_layout, from, to);
                    rolodexList.setAdapter(adapter);

                    listFirstName.set(selectedIndex, firstName.getText().toString());
                    listLastName.set(selectedIndex, lastName.getText().toString());
                    listMiddleName.set(selectedIndex, middleName.getText().toString());
                    listPhoneNumber.set(selectedIndex, phoneNumber.getText().toString());

                    DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);
                    boolean success = dataBaseHelper.updateData(Integer.toString(selectedIndex + 1), firstName.getText().toString(), lastName.getText().toString(), middleName.getText().toString(), phoneNumber.getText().toString());

                    updateDialog.dismiss();
                }
                else{
                    Toast.makeText(MainActivity.this, "The record wasn't updated because of invalid information!!!", Toast.LENGTH_LONG).show();
                    updateDialog.dismiss();
                }
            }
        });



    }

    public void openConfirmDialog(){
        Dialog confirmDelete = new Dialog(MainActivity.this);
        confirmDelete.setTitle("CONFIRMATION");
        confirmDelete.setContentView(R.layout.confirm_delete_dialog);
        confirmDelete.show();
        Button okay = confirmDelete.findViewById(R.id.okay);
        Button cancel = confirmDelete.findViewById(R.id.cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDelete.dismiss();
            }
        });

        okay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteRecords();
                Toast.makeText(MainActivity.this, "Selected records were deleted!", Toast.LENGTH_LONG).show();
                confirmDelete.dismiss();
            }
        });
    }

    public void deleteRecords(){
        DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);
        for (int i = 0 ; i < index ; i++){
            if (list.get(i).get("select").equals("Selected")){
                list.remove(i);
                removeItemFromLists(i);
                dataBaseHelper.DeleteOne(i+1);
                i--;
                index--;

            }
        }
        dataBaseHelper.deleteDatabase(MainActivity.this);
        addOldRecordsToDB();
        SimpleAdapter adapter = new SimpleAdapter(this, list, R.layout.item_layout, from, to);
        rolodexList.setAdapter(adapter);
    }

    public void addOldRecordsToDB(){
        DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);
        for (int i = 0 ; i < listFirstName.size(); i++){
            dataBaseHelper.addOne(listFirstName.get(i), listLastName.get(i),listMiddleName.get(i), listPhoneNumber.get(i));
        }
    }

    public void selectItem(int i){
        if (list.get(i).get("select").equals("")) {
            item[i] = new HashMap<>();
            item[i].put("select", "Selected");
            item[i].put("name", list.get(i).get("name"));
            item[i].put("phone", list.get(i).get("phone"));
            list.set(i, item[i]);
            SimpleAdapter adapter = new SimpleAdapter(this, list, R.layout.item_layout, from, to);
            rolodexList.setAdapter(adapter);
        }
        else if (list.get(i).get("select").equals("Selected")) {
            item[i] = new HashMap<>();
            item[i].put("select", "");
            item[i].put("name", list.get(i).get("name"));
            item[i].put("phone", list.get(i).get("phone"));
            list.set(i, item[i]);
            SimpleAdapter adapter = new SimpleAdapter(this, list, R.layout.item_layout, from, to);
            rolodexList.setAdapter(adapter);
        }
    }

    public int countSelectItem(){
        int count=0;
        for (int i=0 ; i<index; i++){
            if (list.get(i).get("select").equals("Selected")){
                count++;
            }
        }
        return count;
    }

    public int getSelectItem(){
        for (int i=0 ; i<index; i++){
            if (list.get(i).get("select").equals("Selected")){
                return i;
            }
        }
        return -1;
    }

    public void removeItemFromLists(int i){
        listFirstName.remove(i);
        listLastName.remove(i);
        listMiddleName.remove(i);
        listPhoneNumber.remove(i);
    }

    private boolean validation(String fname, String lname, String mname, String phone) {
        if (fname.length() == 0) {
            return false;
        }
        if (!fname.matches("[a-zA-Z]+")) {
            return false;
        }

        if (lname.length() == 0) {
            return false;
        }
        if (!lname.matches("[a-zA-Z]+")) {
            return false;
        }

        if (mname.length() != 0) {
            if (!mname.matches("[a-z .A-Z]+")) {
                return false;
            }
        }
        if (phone.length() == 0){
            return false;
        }

        if (!phone.matches("[0-9]+")){
            return false;
        }

        return true;
    }
}