package henry.android.rolodex;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.fragment.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class addRolodex extends AppCompatDialogFragment {
    private EditText firstName, lastName, middleName, phoneNumber;
    private ExampleDialogListener listener;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();

        View view = inflater.inflate(R.layout.add_rolodex_fragment, null);

        builder.setView(view)
                .setTitle("Add New Record")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setPositiveButton("Okay", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                         if (validation()) {
                            String getFirstName = firstName.getText().toString();
                            String getLastName = lastName.getText().toString();
                            String getMiddleName = middleName.getText().toString();
                            String getPhoneNumber = phoneNumber.getText().toString();
                            listener.applyTexts(getFirstName, getLastName, getMiddleName, getPhoneNumber);
                        }
                         else{
                             listener.applyTexts("","","","");
                         }
                    }
                });

        firstName = view.findViewById(R.id.firstName);
        lastName = view.findViewById(R.id.lastName);
        middleName = view.findViewById(R.id.middleName);
        phoneNumber = view.findViewById(R.id.phoneNumber);


        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listener = (ExampleDialogListener) context;
        } catch (ClassCastException e){
            throw new ClassCastException(context.toString() + "must implement ExampleDialogListener");
        }
    }

    public interface ExampleDialogListener{
        void applyTexts(String getFirstName, String getLastName, String getMiddleName, String getPhoneNumber);
    }

    private boolean validation() {
        String fname = firstName.getText().toString();
        String lname = lastName.getText().toString();
        String mname = middleName.getText().toString();
        String phone = phoneNumber.getText().toString();

        if (fname.length() == 0) {
            return false;
        }
        if (!fname.matches("[a-zA-Z]+")) {
            return false;
        }

        if (lname.length() == 0) {
            return false;
        }
        if (!lname.matches("[a-zA-Z]+")) {
            return false;
        }

        if (mname.length() != 0) {
            if (!mname.matches("[a-z .A-Z]+")) {
                return false;
            }
        }
        if (phone.length() == 0){
            return false;
        }

        if (!phone.matches("[0-9]+")){
            return false;
        }

        return true;
    }

}
