package com.example.stopwatch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private Chronometer stopWatch;
    private long pauseOffset;
    private boolean running;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        stopWatch = findViewById(R.id.stopwatch);
        stopWatch.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer){
                if (((String) stopWatch.getText()).equals("00:59:59")) {
                    stopWatch.setFormat("0%s");
                }

                if (((String) stopWatch.getText()).equals("09:59:59")) {
                    stopWatch.setFormat("%s");
                }
            }
        });
    }


    public void startWatch(View v){
        if (!running){
            stopWatch.setBase(SystemClock.elapsedRealtime() - pauseOffset);
            stopWatch.start();
            running = true;
        }
    }

    public void pauseWatch(View v){
        if (running){
            stopWatch.stop();
            pauseOffset = SystemClock.elapsedRealtime() - stopWatch.getBase();
            running = false;
        }
    }

    public void resetWatch(View v){
        stopWatch.setBase(SystemClock.elapsedRealtime());
        stopWatch.setFormat("00:%s");
        stopWatch.stop();
        running = false;
        pauseOffset = 0;
    }
}